document.addEventListener("deviceready", function () { StatusBar.hide(); }, false);
